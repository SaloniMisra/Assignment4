package com.example.exammanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExammanagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExammanagementApplication.class, args);
	}

}
