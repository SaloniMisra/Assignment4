package com.example.exammanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExammanagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
